# bybitSignals-Telegram-Bot
 Bybit signals telegram bot. 

 Execute trades on your bybit based on entry signals posted in telegram channel
